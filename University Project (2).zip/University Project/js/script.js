$(document).ready(function(){  
    $(window).scroll(function(){
    if ($(this).scrollTop() > 100) {
    $('.scrollup').fadeIn();
    } else {
    $('.scrollup').fadeOut();
    }
    });
     
    $('.scrollup').click(function(){
    $("html, body").animate({ scrollTop: 0 }, 400);
    return false;
    });
    $('.header_burger').click(function(event){
        $('.header_burger,.links1').toggleClass('active');
    });
    $('.links1 li:first-child').click(function(event){
        $('.submenu.first').toggleClass('active');
        $('.submenu.second').removeClass('active');
        $('.submenu.third').removeClass('active');
        $('.submenu.fourth').removeClass('active');
    });    
    $('.links1 li:nth-child(2)').click(function(event){
        $('.submenu.second').toggleClass('active');
        $('.submenu.first').removeClass('active');
        $('.submenu.third').removeClass('active');
        $('.submenu.fourth').removeClass('active');
    }); 
    $('.links1 li:nth-child(3)').click(function(event){
        $('.submenu.third').toggleClass('active');
        $('.submenu.first').removeClass('active');
        $('.submenu.second').removeClass('active');
        $('.submenu.fourth').removeClass('active');
    }); 
    $('.links1 li:nth-child(4)').click(function(event){
        $('.submenu.fourth').toggleClass('active');
        $('.submenu.first').removeClass('active');
        $('.submenu.second').removeClass('active');
        $('.submenu.third').removeClass('active');
    });
});
